package com.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Parker;

/**
 * Servlet implementation class Select
 */
@WebServlet("/Select")
public class Select extends HttpServlet implements Servlet {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		//String lat = request.getParameter("lat");
		//String lng = request.getParameter("long");	
		String day = request.getParameter("day");
		String adr = request.getParameter("adr");
		
		Parker pm = new Parker();
		
		/**List result = null;
		try {
			result = pm.mainFunc(lat, lng, day);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}**/
		
		ArrayList<String> result = null;
		try {
			//result = pm.mainFunc(lat, lng, day);
			result = pm.mainFunc2(adr, day);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		request.setAttribute("spaces",result);		
		 
	   	RequestDispatcher dispatcher = request.getRequestDispatcher("result.jsp");
		dispatcher.forward(request,response);
		
		
	}

}