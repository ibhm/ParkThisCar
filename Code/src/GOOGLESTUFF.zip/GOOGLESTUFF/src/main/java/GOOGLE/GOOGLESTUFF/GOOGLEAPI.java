package GOOGLE.GOOGLESTUFF;

import java.io.IOException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.errors.ApiException;
import com.google.maps.model.GeocodingResult;
import com.sun.xml.bind.v2.schemagen.xmlschema.List;

import geo.google.GeoAddressStandardizer;
import geo.google.datamodel.GeoAddress;
import geo.google.datamodel.GeoCoordinate;

public class GOOGLEAPI{
	
	public static String GOOGLEAPISTUFF(String address, String City, String State) throws ApiException, InterruptedException, IOException{
		String address2 = (address + " "+ City +" "+ State);
		//String address2 = (address + "Seattle WA");
		GeoApiContext context = new GeoApiContext.Builder().apiKey("AIzaSyCM3UXECBqRR8qqvOurDFPtWIBI-_Yu1uU"
).build();
		GeocodingResult[] results =  GeocodingApi.geocode(context,
		   address2).await();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		//results2 = gson.toJson(results[0].addressComponents);
		//System.out.println(gson.toJson(results[0].addressComponents));
		String lataddFrom = gson.toJson(results[0].geometry.location.lat);
		String lngaddFrom = gson.toJson(results[0].geometry.location.lng);
		String Coord = (lataddFrom+", "+lngaddFrom);
		return Coord;
	}
	
	
	/**
	//This code below is only to verify that the function above will work and produce addFrom, when addTo is given to it
    public static void main(String[] args) throws ApiException, InterruptedException, IOException
    {
    	String addto = "1435 14TH STREET NE";
    	String city = "Auburn";
    	String state = "WA";
    	//String addto = args[0]+args[1]+args[2]+args[3]+args[4]+args[5];
    	String Result = GOOGLEAPISTUFF(addto, city, state);
        System.out.println(Result);
    }
    /**
	 * @throws IOException 
	 * @throws InterruptedException 
	 * @throws ApiException 
    
    public static void main(String[] args ) throws ApiException, InterruptedException, IOException{
	GeoApiContext context = new GeoApiContext.Builder().apiKey("AIzaSyCiNoDpre_XOIgY4dW1_8-IRu4H70-GXrA").build();
	String addto = args[0]+args[1]+args[2]+args[3]+args[4]+args[5];
	GeocodingResult[] results =  GeocodingApi.geocode(context,
	   addto).await();
	Gson gson = new GsonBuilder().setPrettyPrinting().create();
	//results2 = gson.toJson(results[0].addressComponents);
	System.out.println(gson.toJson(results[0].geometry.location.lat));//prints out lat only
    }*/
}